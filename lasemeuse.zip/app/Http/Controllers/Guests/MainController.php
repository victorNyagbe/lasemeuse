<?php

namespace App\Http\Controllers\Guests;

use App\Models\Invoice;
use Illuminate\Http\Request;
use App\Models\NewsletterContact;
use Illuminate\Contracts\View\View;
use App\Http\Controllers\Controller;
use App\Http\Requests\InvoiceRequest;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Event;
use App\Events\NewsletterRegisteredEvent;

class MainController extends Controller
{
    public function home(): View
    {
        return view('pages.guests.home');
    }

    public function about(): View
    {
        return view('pages.guests.about');
    }

    public function services(): View
    {
        return view('pages.guests.services');
    }

    public function realisations(): View
    {
        return view('pages.guests.realisations');
    }

    public function team(): View
    {
        return view('pages.guests.team');
    }

    public function albumIndex(): View
    {
        return view('pages.guests.album.index');
    }

    public function albumShow(): View
    {
        return view('pages.guests.album.show');
    }

    public function contact(): View
    {
        return view('pages.guests.contact');
    }

    public function invoiceView(): View
    {
        return view('pages.guests.invoice');
    }

    public function invoice(InvoiceRequest $request): RedirectResponse
    {
        $fields = $request->validated();

        $invoice = Invoice::create($fields);

        return redirect()->back()->with("success", "La demande a bien été envoyée");
    }

    public function storeNewsletterMail(Request $request): RedirectResponse
    {
        $request->validate([
            "newsletter-email" => "required|email|unique:newsletter_contacts,email"
        ], [
            "newsletter-email.required" => "Votre adresse mail est requise",
            "newsletter-email.email" => "Votre adresse mail est invalide",
            "newsletter-email.unique" => "Cette adresse mail est déjà enregistrée"
        ]);

        $newsletter = NewsletterContact::create([
            "email" => $request->input("newsletter-email")
        ]);

        Event::dispatch(new NewsletterRegisteredEvent($newsletter->email));

        return redirect()->back()->with('newsletter-success', "success");
    }
}
