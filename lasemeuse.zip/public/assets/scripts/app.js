const closeMailModal = (element) => {
    const mailContainer = element.closest(".mail-container");
    mailContainer.style.display = "none";
}
