<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>LA SEMEUSE</title>
    <link rel="stylesheet" href="{{ asset('assets/styles/guests/app.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/styles/guests/navbar.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/styles/guests/footer.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/styles/aos.min.css') }}">
    <link rel="stylesheet" href="{{ asset('fontawesome/css/all.css') }}">
    @yield('extra-styles')
</head>
<body>
    @include('includes.guests.navbar')
    <main>
        @yield('content')
    </main>
    @include('includes.guests.footer')

    <a href="#" class="whatsapp-fixed-icon">
        <i class="fab fa-whatsapp"></i>
    </a>

    <script src="{{ asset('assets/scripts/navbar.js') }}"></script>
    <script src="{{ asset('assets/scripts/app.js') }}"></script>
    <script src="{{ asset('assets/scripts/aos.min.js') }}"></script>
    <script>
        AOS.init();
    </script>
    @yield('extra-scripts')
</body>
</html>
