@extends('layouts.app')

@section('extra-styles')
    <link rel="stylesheet" href="{{ asset('assets/styles/guests/album/show.css') }}">
@endsection

@section('content')
    <div class="photo-header-container">
        <div class="photo-header-cover">
            <h1 class="photo-header-title">Phototèque</h1>
            <ol class="page-header-breadcrumb">
                <li>
                    <a href="{{ route('guests.album.index') }}">/ Liste des albums</a>
                </li>
            </ol>
        </div>
    </div>
    <section class="container">
        <h1>Rencontre avec le président avec l'association</h1>
        @php
            $imageClasses = ['img-2x2', 'img-1x1', 'img-1x1', 'img-2x2'];
        @endphp

        <div class="files-grid">
            <img src="{{ asset('assets/images/about1.jpg') }}" alt="" class="img-1x1">
        </div>
    </section>
@endsection

@section('extra-scripts')

@endsection
