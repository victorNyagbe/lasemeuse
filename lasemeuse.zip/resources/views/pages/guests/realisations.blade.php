@extends('layouts.app')

@section('extra-styles')
    <link rel="stylesheet" href="{{ asset('assets/styles/guests/realisations.css') }}">
@endsection

@section('content')
    <div class="realisaations-header-container">
        <div class="realisations-header-cover">
            <h1 class="realisations-header-title">Nos réalisations</h1>
            <p class="realisations-header-subtitle">Découvrez toutes nos réalisations</p>
        </div>
    </div>

    <section class="container">
        <div class="realisations-content">
            @for ($i = 0; $i < 2; $i++)
                <div class="realisation-item" data-aos="flip-down" data-aos-duration="800">
                    <figure class="realisation-image">
                        <img src="{{ asset('assets/images/img1.jpg') }}" alt="Image de realisation">
                        <div class="realisation-info">
                            <h5 class="realisation-title">Titre de la realisation</h5>
                        </div>
                    </figure>
                </div>
                <div class="realisation-item" data-aos="flip-down" data-aos-duration="800">
                    <figure class="realisation-image">
                        <img src="{{ asset('assets/images/img2.jpg') }}" alt="Image de realisation">
                        <div class="realisation-info">
                            <h5 class="realisation-title">Titre de la realisation</h5>
                        </div>
                    </figure>
                </div>
            @endfor
        </div>
    </section>
@endsection

@section('extra-scripts')

@endsection
