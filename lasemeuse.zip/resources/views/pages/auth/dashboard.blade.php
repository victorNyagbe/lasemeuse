@extends('layouts.auth')

@section('extra-style')

@endsection

@section('content')
    <h1>Tableau de bord</h1>
@endsection

@section('extra-script')

@endsection
