<footer>
    <div class="footer-first-content">
        <figure class="footer-logo">
            <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="Logo">
            <figcaption>En continu, LA SEMEUSE roule pour vous ...!</figcaption>
        </figure>

        <ul class="footer-menu">
            <li><a href="">Accueil</a></li>
            <li><a href="">Qui sommes-nous</a></li>
            <li><a href="">Nos services</a></li>
            <li><a href="">Notre équipe</a></li>
            <li><a href="">Nos réalisations</a></li>
            <li><a href="">Notre équipe</a></li>
            <li><a href="">Actualités</a></li>
            <li><a href="">Contact</a></li>
        </ul>

        <div class="footer-contact">
            <p>Adresse : 123, rue de la République</p>
            <p><i class="fa fa-phone"></i> : 01 23 45 67 89</p>
            <p><i class="fa fa-envelope"></i> : <a href="mailto:info@semeuse.com">info@semeuse.com</a></p>
            <ul class="social-icons-links">
                <li><a href=""><i class="fab fa-facebook"></i></a></li>
                <li><a href=""><i class="fab fa-x-twitter"></i></a></li>
                <li><a href=""><i class="fab fa-instagram"></i></a></li>
            </ul>
        </div>
    </div>
    <div class="footer-second-content">
        <p>Copyright &copy; 2024 Semeuse. Tous droits réservés.</p>
        <p>Site réalisé par <a href="https://wa.me/22897374862">Mr Mensa See</a>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\lasemeuse\resources\views/includes/guests/footer.blade.php ENDPATH**/ ?>