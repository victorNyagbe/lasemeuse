<?php $__env->startSection('extra-styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/styles/guests/team.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="team-header-container">
        <div class="team-header-cover">
            <h1 class="team-header-title">Notre équipe</h1>
            <p class="team-header-subtitle">Découvrez toute l'équipe</p>
        </div>
    </div>

    <section class="container">
        <div class="team-content">
            <?php for($i = 0; $i < 2; $i++): ?>
                <div class="team-member" data-aos="fade-up" data-aos-duration="1000">
                    <figure class="team-member-image">
                        <img src="<?php echo e(asset('assets/images/img.jpg')); ?>" alt="Image de membre">
                    </figure>
                    <div class="team-member-info">
                        <h5 class="team-member-name">NOM PRENOMS</h5>
                        <p class="team-member-poste">poste</p>
                    </div>
                </div>
                <div class="team-member" data-aos="fade-up" data-aos-duration="1000">
                    <figure class="team-member-image">
                        <img src="<?php echo e(asset('assets/images/profile1.png')); ?>" alt="Image de membre">
                    </figure>
                    <div class="team-member-info">
                        <h5 class="team-member-name">NOM PRENOMS</h5>
                        <p class="team-member-poste">poste</p>
                    </div>
                </div>
            <?php endfor; ?>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lasemeuse\resources\views/pages/guests/team.blade.php ENDPATH**/ ?>