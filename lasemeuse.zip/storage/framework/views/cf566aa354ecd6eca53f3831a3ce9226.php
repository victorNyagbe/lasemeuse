<?php $__env->startSection('extra-style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('summernote/summernote-lite.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('summernote/summernote-lite.css.map')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/styles/auth/about.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page__header__container">
        <h1 class="page__header__title">Qui sommes-nous</h1>
    </div>

    <div class="page__content__container">

        <?php echo $__env->make('includes.auth.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <form action="<?php echo e(route('auth.about.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form__group">
                <textarea name="about" id="about" rows="10" placeholder="Qui sommes-nous" class="input__form"><?php echo $content->body; ?></textarea>
            </div>
            <div class="form__button">
                <button type="submit" class="button__green">Enregistrer le texte</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-script'); ?>
    <script src="<?php echo e(asset('assets/scripts/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('summernote/summernote-lite.js')); ?>"></script>
    <script src="<?php echo e(asset('summernote/summernote-lite.js.map')); ?>"></script>
    <script src="<?php echo e(asset('summernote/lang/summernote-fr-FR.js')); ?>"></script>
    <script>
        $(document).ready(function () {
            $('#about').summernote({
                placeholder: "Qui sommes-nous...",
                lang: 'fr-FR',
                height: 300,
                toolbar: [
                    ['style', ['style']],
                    ['font', ['bold', 'italic', 'underline', 'clear']],
                    ['para', ['ul', 'ol', 'paragraph']],
                    ['insert', ['link', 'picture']],
                ]
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lasemeuse\resources\views/pages/auth/about.blade.php ENDPATH**/ ?>