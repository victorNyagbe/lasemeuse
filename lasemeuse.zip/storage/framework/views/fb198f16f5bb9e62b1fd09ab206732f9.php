<?php $__env->startSection('extra-style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/styles/auth/invoice.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page__header__container">
        <h1 class="page__header__title">Demande de devis</h1>
    </div>
    <div class="page__content__container">
        <div class="invoice__container">
            <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="invoice__item">
                    <div class="invoice__header">
                        <div class="invoice__left">
                            <span class="invoice__date"><i class="fas fa-calendar"></i> <?php echo e(Carbon\Carbon::parse($invoice->created_at)->format("d/m/Y")); ?></span>
                            <span class="invoice__id">#<?php echo e($invoice->invoice_id); ?></span>
                            <span class="invoice__name"><?php echo e($invoice->fullname); ?></span>
                            <span class="invoice__phone"><?php echo e($invoice->phone); ?></span>
                        </div>
                        <div class="invoice__right">
                            <?php if($invoice->is_viewed): ?>
                                <span class="declared">Déclaré</span>
                            <?php else: ?>
                                <a href="#!" onclick="event.preventDefault(); document.getElementById('declareInvoice<?php echo e($invoice->id); ?>').submit()" class="primary__link__btn">Déclarer</a>

                            <?php endif; ?>
                        </div>
                        <form action="<?php echo e(route('auth.declareInvoice', $invoice)); ?>" method="post" id="declareInvoice<?php echo e($invoice->id); ?>" hidden>
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                    <div class="invoice__body">
                        <?php echo $invoice->message; ?>

                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lasemeuse\resources\views/pages/auth/invoice.blade.php ENDPATH**/ ?>