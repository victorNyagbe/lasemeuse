<?php $__env->startSection('extra-styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/styles/guests/invoice.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="invoice-header-container">
        <div class="invoice-header-cover">
            <h1 class="invoice-header-title">Demande de devis</h1>
            
        </div>
    </div>

    <section class="container">
        <?php echo $__env->make('includes.auth.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="invoice-content">
            <form action="<?php echo e(route('guests.invoice')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-row">
                    <div class="form-group">
                        <label for="fullname">Nom & Prénom(s)</label>
                        <input type="text" name="fullname" id="fullname" placeholder="Votre nom complet...">
                    </div>
                    <div class="form-group">
                        <label for="email">Adresse e-mail</label>
                        <input type="email" name="email" id="email" placeholder="Votre adresse e-mail...">
                    </div>
                    <div class="form-group">
                        <label for="phone">Téléphone</label>
                        <input type="tel" name="phone" id="phone" placeholder="Votre numéro de téléphone">
                    </div>
                </div>
                <div class="form-group">
                    <label for="message">Message</label>
                    <textarea name="message" id="message" rows="15" placeholder="Votre message..."></textarea>
                </div>
                <div class="form-group">
                    <button type="submit">Envoyer la demande</button>
                </div>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-scripts'); ?>
    <script>
        const closeAlert = (element) => {
            const alertContainer = element.parentNode;

            alertContainer.style.display = "none";
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lasemeuse\resources\views/pages/guests/invoice.blade.php ENDPATH**/ ?>