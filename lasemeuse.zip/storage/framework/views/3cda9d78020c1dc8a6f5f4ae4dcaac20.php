<?php $__env->startSection('extra-styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/styles/guests/album/show.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="photo-header-container">
        <div class="photo-header-cover">
            <h1 class="photo-header-title">Phototèque</h1>
            <ol class="page-header-breadcrumb">
                <li>
                    <a href="<?php echo e(route('guests.album.index')); ?>">/ Liste des albums</a>
                </li>
            </ol>
        </div>
    </div>
    <section class="container">
        <h1>Rencontre avec le président avec l'association</h1>
        <?php
            $imageClasses = ['img-2x2', 'img-1x1', 'img-1x1', 'img-2x2'];
        ?>

        <div class="files-grid">
            <img src="<?php echo e(asset('assets/images/about1.jpg')); ?>" alt="" class="img-1x1">
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lasemeuse\resources\views/pages/guests/album/show.blade.php ENDPATH**/ ?>