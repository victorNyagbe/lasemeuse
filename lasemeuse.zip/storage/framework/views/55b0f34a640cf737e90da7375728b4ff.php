<?php $__env->startSection('extra-style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/styles/auth/realisation.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page__header__container">
        <h1 class="page__header__title">Gestion des réalisations</h1>
    </div>
    <div class="page__content__container">

        <a href="#" class="primary__link__btn" onclick="modalOpener(this)" data-target="#addRealisation"><i class="fa fa-plus"></i> Ajouter une réalisation</a>

        <?php echo $__env->make('includes.auth.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="realisation__card__container">
            <?php $__currentLoopData = $realisations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $realisation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="realisation__card">
                    <figure class="realisation__image">
                        <img src="<?php echo e(asset('storage/' . $realisation->image)); ?>" alt="Image de la réalisation">
                        <div class="realisation__description"><?php echo e($realisation->title); ?></div>
                    </figure>
                    <div class="realisation__content">
                        <a href="#!" class="edit__button" onclick="modalOpener(this)" data-target="#addRealisation1">Modifier</a>
                        <a href="#!" onclick="event.preventDefault(); confirm('Etes-vous sûr de vouloir supprimer cette réalisation ?') ? document.getElementById('deleteRealisation<?php echo e($realisation->id); ?>').submit() : ''" class="delete__button">Supprimer</a>
                            <form action="<?php echo e(route('auth.realisations.destroy', $realisation)); ?>" method="POST" id="deleteRealisation<?php echo e($realisation->id); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field("DELETE"); ?>
                            </form>
                    </div>

                    <div class="modal__container" id="addRealisation1">
                        <div class="modal">
                            <div class="modal__body">
                                <form action="<?php echo e(route('auth.realisations.update', $realisation)); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field("PATCH"); ?>
                                    <div class="form__group">
                                        <label for="title" class="form__label">Titre</label>
                                        <textarea name="title" id="title" rows="3" placeholder="Titre de la réalisation" class="input__form"><?php echo $realisation->title; ?></textarea>
                                    </div>
                                    <div class="form__group">
                                        <label for="" class="form__label">Image de la réalisation</label>
                                        <label for="" class="input__file__container">
                                            <i class="fa fa-image"></i>
                                            <input type="file" name="image" id="" class="input__file" onchange="uploadFile(this)">
                                            <span class="file__name">Choisir une image</span>
                                        </label>
                                    </div>
                                    <div class="form__button">
                                        <button type="submit" class="button__green">Enregistrer la réalisation</button>
                                        <button type="button" class="close__button closeModal" onclick="closeModal(this)">Annuler</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="modal__container" id="addRealisation">
            <div class="modal">
                <div class="modal__body">
                    <form action="<?php echo e(route('auth.realisations.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form__group">
                            <label for="title" class="form__label">Titre</label>
                            <textarea name="title" id="title" rows="3" placeholder="Titre de la réalisation" class="input__form"></textarea>
                        </div>
                        <div class="form__group">
                            <label for="" class="form__label">Image de la réalisation</label>
                            <label for="" class="input__file__container">
                                <i class="fa fa-image"></i>
                                <input type="file" name="image" id="" class="input__file" onchange="uploadFile(this)">
                                <span class="file__name">Choisir une image</span>
                            </label>
                        </div>
                        <div class="form__button">
                            <button type="submit" class="button__green">Enregistrer la réalisation</button>
                            <button type="button" class="close__button closeModal" onclick="closeModal(this)">Annuler</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-script'); ?>
    <script>
        const modalOpener = (element) => {
            const targetSelector = element.dataset.target;
            const modal = document.querySelector(targetSelector);
            modal.style.display = "flex";
        };

        const uploadFile = (element) => {
            const fileInput = element;

            const fileContainer = fileInput.parentNode;
            const fileSpan = fileContainer.querySelector('.file__name');


            if (fileInput.files.length >= 1) {
                const fileName = fileInput.files[0].name;
                let fileSize = fileInput.files[0].size;
                fileSize = (fileSize / 1024).toFixed(2) + " ko";

                fileContainer.style.borderColor = "#006ccb";
                fileContainer.style.backgroundColor = "#dfeeff";
                fileSpan.textContent = `${fileName}, ${fileSize}` ;
            } else {
                fileContainer.style.borderColor = "#000";
                fileContainer.style.backgroundColor = "#fff";
                fileSpan.textContent = "Choisir une image" ;
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lasemeuse\resources\views/pages/auth/realisation.blade.php ENDPATH**/ ?>