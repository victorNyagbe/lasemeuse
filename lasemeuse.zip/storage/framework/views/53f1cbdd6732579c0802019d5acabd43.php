<?php $__env->startSection('extra-styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/styles/guests/album/index.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="photo-header-container">
        <div class="photo-header-cover">
            <h1 class="photo-header-title">Phototèque</h1>
            <p class="photo-header-subtitle">Vivez les moments forts et importants à travers nos albums</p>
        </div>
    </div>
    <section class="container">
        <div class="album-grid">
            <?php for($i = 0; $i < 5; $i++): ?>
                <div class="album-card">
                    <figure class="album-card-media">
                        <img src="<?php echo e(asset('assets/images/about1.jpg')); ?>" alt="" width="100%">
                        <div class="album-card-content">
                            <h5><strong>Rencontre avec le president de l'association</strong></h5>
                            <a href="<?php echo e(route('guests.album.show')); ?>" class="see-album">
                                <span>&plus;</span>
                            </a>
                        </div>
                    </figure>
                </div>
            <?php endfor; ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lasemeuse\resources\views/pages/guests/album/index.blade.php ENDPATH**/ ?>