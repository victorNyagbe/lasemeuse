<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('assets/styles/auth/base.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/styles/auth/sidebar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('fontawesome/css/all.css')); ?>">
    
    <?php echo $__env->yieldContent('extra-style'); ?>
    <title>ADMIN | LA SEMEUSE</title>
</head>
<body>
    <?php echo $__env->make('includes.auth.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    
    <script src="<?php echo e(asset('assets/scripts/base.js')); ?>"></script>
    <?php echo $__env->yieldContent('extra-script'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\lasemeuse\resources\views/layouts/auth.blade.php ENDPATH**/ ?>