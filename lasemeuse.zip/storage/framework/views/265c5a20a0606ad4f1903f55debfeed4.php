<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>LA SEMEUSE</title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/styles/guests/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/styles/guests/navbar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/styles/guests/footer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/styles/aos.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('fontawesome/css/all.css')); ?>">
    <?php echo $__env->yieldContent('extra-styles'); ?>
</head>
<body>
    <?php echo $__env->make('includes.guests.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <?php echo $__env->make('includes.guests.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <a href="#" class="whatsapp-fixed-icon">
        <i class="fab fa-whatsapp"></i>
    </a>

    <script src="<?php echo e(asset('assets/scripts/navbar.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/scripts/app.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/scripts/aos.min.js')); ?>"></script>
    <script>
        AOS.init();
    </script>
    <?php echo $__env->yieldContent('extra-scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\lasemeuse\resources\views/layouts/app.blade.php ENDPATH**/ ?>