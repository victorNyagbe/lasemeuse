<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Mail</title>
    <style>
        .message_container, p, ul li {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
            font-size: 1rem;
        }
    </style>
</head>
<body>
    <div class="message_container">
        <?php echo e($data['message']); ?>

    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\lasemeuse\resources\views/mails/auth/newsletterMessage.blade.php ENDPATH**/ ?>