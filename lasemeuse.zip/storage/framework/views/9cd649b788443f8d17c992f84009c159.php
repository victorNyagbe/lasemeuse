<?php if($type == "danger"): ?>
    <div class="alert alert-danger">
        <span class="alert-message">
            <strong><?php echo e($message); ?></strong>
        </span>
        <span onclick="closeAlert(this)" class="cursor-pointer">&times;</span>
    </div>
<?php endif; ?>

<?php if($type == "success"): ?>
    <div class="alert alert-success">
        <span class="alert-message">
            <strong><?php echo e($message); ?></strong>
        </span>
        <span onclick="closeAlert(this)" class="cursor-pointer text-2xl">&times;</span>
    </div>
<?php endif; ?>

<?php if($type == "errors"): ?>
    <div class="alert alert-errors">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <span onclick="closeAlert(this)" class="cursor-pointer text-2xl">&times;</span>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\lasemeuse\resources\views/components/alert.blade.php ENDPATH**/ ?>