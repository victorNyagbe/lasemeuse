<div class="mail-container">
    <div class="mail-modal">
        <div class="mail-body">
            <figure class="mail-icon">
                <img src="<?php echo e(asset('assets/images/check.svg')); ?>" alt="">
            </figure>
            <p class="mail-text">
                Votre adresse mail a été enregistrée avec succès. Nous vous remercions.
            </p>
            <a href="#!" onclick="event.preventDefault(); closeMailModal(this);" class="closeMailModal">Fermer</a>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\lasemeuse\resources\views/includes/guests/mail_success.blade.php ENDPATH**/ ?>