<?php $__env->startSection('extra-styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/styles/guests/realisations.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="realisaations-header-container">
        <div class="realisations-header-cover">
            <h1 class="realisations-header-title">Nos réalisations</h1>
            <p class="realisations-header-subtitle">Découvrez toutes nos réalisations</p>
        </div>
    </div>

    <section class="container">
        <div class="realisations-content">
            <?php for($i = 0; $i < 2; $i++): ?>
                <div class="realisation-item" data-aos="flip-down" data-aos-duration="800">
                    <figure class="realisation-image">
                        <img src="<?php echo e(asset('assets/images/img1.jpg')); ?>" alt="Image de realisation">
                        <div class="realisation-info">
                            <h5 class="realisation-title">Titre de la realisation</h5>
                        </div>
                    </figure>
                </div>
                <div class="realisation-item" data-aos="flip-down" data-aos-duration="800">
                    <figure class="realisation-image">
                        <img src="<?php echo e(asset('assets/images/img2.jpg')); ?>" alt="Image de realisation">
                        <div class="realisation-info">
                            <h5 class="realisation-title">Titre de la realisation</h5>
                        </div>
                    </figure>
                </div>
            <?php endfor; ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lasemeuse\resources\views/pages/guests/realisations.blade.php ENDPATH**/ ?>