<nav class="navbar">
    <div class="navbar-left-content">
        <div class="navbar-icon-container">
            <i class="fa fa-bars navbar-icon"></i>
        </div>
        <figure class="navbar-logo">
            <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="Logo">
        </figure>
    </div>
    <div class="navbar-right-content">
        <ul class="navbar-menu">
            <li><a href="<?php echo e(route('guests.home')); ?>">Accueil</a></li>
            <li><a href="<?php echo e(route('guests.about')); ?>">Qui sommes-nous</a></li>
            <li><a href="<?php echo e(route('guests.services')); ?>">Nos services</a></li>
            <li><a href="<?php echo e(route('guests.realisations')); ?>">Nos réalisations</a></li>
            <li><a href="<?php echo e(route('guests.team')); ?>">Notre équipe</a></li>
            <li><a href="<?php echo e(route('guests.album.index')); ?>">Phototèque</a></li>
            <li><a href="<?php echo e(route('guests.contact')); ?>">Contact</a></li>
        </ul>
        <div class="navbar-mobile-social-icons">
            
            <a href="<?php echo e(route('guests.invoice-view')); ?>" class="invoice_header">Devis</a>
        </div>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\lasemeuse\resources\views/includes/guests/navbar.blade.php ENDPATH**/ ?>